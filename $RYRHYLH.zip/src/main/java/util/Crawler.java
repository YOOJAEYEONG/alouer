package util;

import java.util.List;
import java.util.logging.Level;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class Crawler {
	
	public void crawl() {
		
		WebClient webClient = new WebClient();
		java.util.logging.Logger.getLogger("com.gargoylesoftware").setLevel(Level.OFF);//중간로그 off
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		webClient.getOptions().setThrowExceptionOnScriptError(false);
		webClient.getOptions().setJavaScriptEnabled(true);
		webClient.getOptions().setCssEnabled(false);
		webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
		
		int num = 0;
		int end = 9999;
		boolean flag = false;
		
		HtmlPage page;
		try {
			
			while(num!=end) {
				
				System.out.println("현재페이지 : " + num);
				System.out.println("끝페이지 : " + end);
				String url = "https://www.opengallery.co.kr/discover/?p="+ num +"&f_ts=&f_ps=&f_ra=false&f_pa=false&r_ex=0&";
				
				page = webClient.getPage(url);
				
				List<DomElement> aTag = page.getElementsByTagName("a");
				
				
				for (DomElement e : aTag) {				
					
					if(e.getAttribute("class").equals("discoverCard-a")) {
						String dpageUrl = "https://www.opengallery.co.kr" + e.getAttribute("href").toString();
						System.out.println("페이지 URL: " + dpageUrl);
						
					HtmlPage dpage = webClient.getPage(dpageUrl);
					
					List<DomElement> imgTag = dpage.getElementsByTagName("img");
					for (DomElement de : imgTag) {
						if(de.getAttribute("class").equals("artworkDetail-imageViewer-img")) {
							String imgURL = de.getAttribute("src").toString();
							System.out.println("이미지주소 : " + imgURL);
						}
					}				
					}else if((e.getAttribute("class").equals("paginator-btn pb-end")) && flag==false) {
						System.out.println("===========================================");
						System.out.println("페이지번호  :"+e.getTextContent());
						end = Integer.parseInt(e.getTextContent());
						flag = true;
						
					}
				}	
				
				//페이지 조금만 페이지하기 위한 설정
				//num++;
				num++;
				
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void crawl(int startNum, int endNum) {
		
		WebClient webClient = new WebClient();
		java.util.logging.Logger.getLogger("com.gargoylesoftware").setLevel(Level.OFF);//중간로그 off
		java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
		webClient.getOptions().setThrowExceptionOnScriptError(false);
		webClient.getOptions().setJavaScriptEnabled(true);
		webClient.getOptions().setCssEnabled(false);
		webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
		
		int num = startNum;
		int end = endNum;
		boolean flag = false;
		
		HtmlPage page;
		try {
			
			while(num!=end) {
				
				System.out.println("현재페이지 : " + num);
				System.out.println("끝페이지 : " + end);
				String url = "https://www.opengallery.co.kr/discover/?p="+ num +"&f_ts=&f_ps=&f_ra=false&f_pa=false&r_ex=0&";
				
				page = webClient.getPage(url);
				
				List<DomElement> aTag = page.getElementsByTagName("a");
				
				
				for (DomElement e : aTag) {				
					
					if(e.getAttribute("class").equals("discoverCard-a")) {
						String dpageUrl = "https://www.opengallery.co.kr" + e.getAttribute("href").toString();
						System.out.println("페이지 URL: " + dpageUrl);
						
						HtmlPage dpage = webClient.getPage(dpageUrl);
						
						List<DomElement> imgTag = dpage.getElementsByTagName("img");
						for (DomElement de : imgTag) {
							if(de.getAttribute("class").equals("artworkDetail-imageViewer-img")) {
								String imgURL = de.getAttribute("src").toString();
								System.out.println("이미지주소 : " + imgURL);
							}
						}				
					}
				}	
				
				num++;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
