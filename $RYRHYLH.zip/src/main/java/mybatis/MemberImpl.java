package mybatis;

public interface MemberImpl {

	public MemberVO login(String id, String pw);
}
