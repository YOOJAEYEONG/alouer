package mybatis;

public class MemberVO {

	private String email;
	private String pass;
	private String name;
	private java.sql.Date regidate;
	
	public String getId() {
		return email;
	}
	public void setId(String id) {
		this.email = id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public java.sql.Date getRegidate() {
		return regidate;
	}
	public void setRegidate(java.sql.Date regidate) {
		this.regidate = regidate;
	}
	
	
}
