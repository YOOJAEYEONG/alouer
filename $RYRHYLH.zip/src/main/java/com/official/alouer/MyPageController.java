package com.official.alouer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyPageController {
	@RequestMapping("/mypage")
	public String mypage() {
		
		return "mypage/list";
	}
	
	@RequestMapping("/mypage2")
	public String mypage2() {
		
		return "mypage/list2";
	}
	
	@RequestMapping("/mypage/deposit")
	public String deposit() {
		 
		return "mypage/deposit";
	}
	
	@RequestMapping("/mypage/modify")
	public String modify() {
		 
		return "mypage/modify";
	}
	
	
	@RequestMapping("/mypage/artist")
	public String artist() {
		
		return "mypage/artist";
	}
	
	
	@RequestMapping("/mypage/art")
	public String art() {
		
		return "mypage/art";
	}
	
	
	@RequestMapping("/mypage/auction")
	public String auction() {
		
		return "mypage/auction";
	}
	
	
	@RequestMapping("/mypage/auction/view.do")
	public String auctionView() {
		
		return "mypage/auction/view.do";
	}
	
	
	@RequestMapping("/mypage/stock")
	public String stock() {
		
		return "mypage/stock";
	}
	
	
	
	@RequestMapping("/mypage/stock/view.do")
	public String stockView() {
		
		return "mypage/stock/view.do";
	}
	
	
	
	@RequestMapping("/mypage/rental")
	public String rental() {
		
		return "mypage/rental";
	}
	
	@RequestMapping("/mypage/inquiry")
	public String inquiry() {
		
		return "mypage/inquiry";
	}
	
	
	
	
}
