package com.official.alouer;

import java.security.Principal;
import java.util.Locale;

import javax.activation.CommandMap;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import mybatis.ParameterDTO;


@Controller
public class MainController {
	
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);

	
	@RequestMapping("/")
	public String main(Locale locale) {
		logger.info("메인페이지요청됨. ", locale);
		
		return "/main";
	}
	
	@RequestMapping("/main")
	public String main_logo(Locale locale) {
		logger.info("메인페이지요청됨(logo). ", locale);
		
		return "/main";
	}
	

	@RequestMapping("/about")
	public String about() {
		
		return "about/about";
	}

	

	
	
	
	/*
	 * @RequestMapping("/member/logout") public String memberLogout(HttpSession
	 * session){ session.setAttribute("userId", null);
	 * 
	 * return "main"; }
	 */
	

	
	
	
	
}


















