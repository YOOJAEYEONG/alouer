package com.official.alouer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RentalController {
	@RequestMapping("/rental")
	public String rental() {
		
		return "rental/list";
	}
	
}
