package com.official.alouer;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import mybatis.ParameterDTO;

@Controller
public class MemberController {
	@RequestMapping("/member")
	public String mypage() {
		
		return "member/list";
	}
	
	@RequestMapping("/member/login")
	public String memberLogin(Authentication authentication, ParameterDTO parameterDTO) {
		System.out.println("memberLogin컨트롤러호출됨");
		if(authentication!=null) {
			System.out.println(authentication.getName());//아이디
			System.out.println(authentication.getAuthorities().toString());//ROLE_ADMIN
			}
		if(parameterDTO.getBackURL()!=null) {
			return "redirect:"+parameterDTO.getBackURL();
		}
		return "member/login";
	}
	
	@RequestMapping("/member/join")
	public String join() {
		 
		return "member/register";
	}
	
	@RequestMapping("/member/find")
	public String find() {
		 
		return "member/find";
	}
	
	
	@RequestMapping("/member/loginAction")
	public String loginAction(HttpServletRequest req) {
		System.out.println("[컨트롤러]loginAction");
		return "/main";
	}
	
	
	@RequestMapping("/member/signUp") 
	public String memberSignUp(){
		return "/member/signUp"; 
	}
	
	@RequestMapping("/member/findAccount") 
	public String memberFindAccount(){
		
		return "/member/findAccount"; 
	}
	
	
	@RequestMapping("/member/accessDenied.do")
	public String accessDenied() {
		
		return "member/accessDenied";
	}
	
	
}
