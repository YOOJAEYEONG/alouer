package com.official.alouer;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import util.Crawler;

@Controller
public class adminController {

	
	@RequestMapping("/admin")
	public String admin() {
		
		
		
		return "admin/main";
	}
	
	@RequestMapping("/admin/crawler")
	public String crawler() {
		return "admin/crawler";
	}
	
	@RequestMapping("/admin/crawler/crawl.do")
	public String letsCrawl(Model model, HttpServletRequest req) {
		Crawler crawler = new Crawler();
		
		int startNum = Integer.parseInt(req.getParameter("startNum"));
		int endNum = Integer.parseInt(req.getParameter("endNum"));
		
		
		crawler.crawl(startNum, endNum);
		
		return "";
	}
	
	

}
